#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "I2C/TWI_Slave.h"
#include <stdio.h>

// Variable global para la distancia medida (8 bits)
volatile uint8_t measured_distance = 0;

// =======================================================
// Funci�n que mide la distancia (en cm) usando el HC-SR04.
// Conexiones: Trig en PC0 (salida) y Echo en PC1 (entrada con pull-up)
// =======================================================
uint16_t measure_distance(void) {
	uint16_t count = 0;
	
	// Asegura que el pin Trig (PC0) est� en bajo.
	PORTC &= ~(1 << PC0);
	_delay_us(2);
	
	// Pulso de 10 �s en Trig.
	PORTC |= (1 << PC0);
	_delay_us(10);
	PORTC &= ~(1 << PC0);
	
	// Espera a que Echo (PC1) se ponga en alto (con timeout).
	uint16_t timeout = 30000;
	while (!(PINC & (1 << PC1)) && timeout) {
		_delay_us(1);
		timeout--;
	}
	if (timeout == 0)
	return 0;
	
	// Mide el ancho del pulso en microsegundos.
	while ((PINC & (1 << PC1)) && count < 60000) {
		_delay_us(1);
		count++;
	}
	
	// Conversi�n aproximada: distancia (cm) = tiempo (�s) / 58.
	uint16_t distance = count / 58;
	if (distance > 255)
	distance = 255; // Limita a 8 bits.
	return distance;
}

// =======================================================
// Configuraci�n del PWM para el servo en el pin PB2 (OC1B)
// Se usa Timer1 en modo Fast PWM (modo 14, ICR1 como TOP)
// con prescaler 8 para obtener una frecuencia de ~50 Hz (20 ms de per�odo).
// Para un servo t�pico:
//   1 ms de pulso ? 0�  (OCR1B ? 2000)
//   1.5 ms de pulso ? 90� (OCR1B ? 3000)
// =======================================================
void servo_init(void) {
	// Configura PB2 como salida (OC1B)
	DDRB |= (1 << PB2);
	
	// Establece el TOP en ICR1 para 20 ms de per�odo:
	// ICR1 = (F_CPU / (prescaler * frecuencia)) - 1 = (16e6/(8*50))-1 = 39999
	ICR1 = 39999;
	
	// Configura Timer1 en Fast PWM, modo 14: WGM13:0 = 14
	// TCCR1A: COM1B1=1 (no inversor en OC1B), WGM11=1
	TCCR1A = (1 << COM1B1) | (1 << WGM11);
	// TCCR1B: WGM13=1, WGM12=1, prescaler = 8 (CS11=1)
	TCCR1B = (1 << WGM13) | (1 << WGM12) | (1 << CS11);
	
	// Inicializa en posici�n 90� (pulso ~1.5 ms)
	OCR1B = 3000;
}

// =======================================================
// ISR del TWI para responder a las solicitudes del maestro.
// Ahora se env�a el valor actualizado de 'measured_distance'.
// =======================================================
ISR(TWI_vect) {
	uint8_t status = TWSR & 0xF8;
	switch (status) {
		case 0x80: // SLA+W recibido (el maestro escribe, no se espera dato)
		{ volatile uint8_t dummy = TWDR; }
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		case 0xA8: // SLA+R recibido: el maestro solicita lectura
		TWDR = measured_distance;  // Env�a el valor medido
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		default:
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
	}
}

// =======================================================
// Funciones UART para depuraci�n (9600 bps)
// =======================================================
void uart_init(void) {
	UBRR0H = 0;
	UBRR0L = 103;  // Para 16 MHz y 9600 bps.
	UCSR0B = (1 << TXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void uart_transmit(char data) {
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = data;
}

void uart_print(char *str) {
	while (*str) {
		uart_transmit(*str++);
	}
}

void uart_println(char *str) {
	uart_print(str);
	uart_transmit('\r');
	uart_transmit('\n');
}

// =======================================================
// Funci�n principal
// =======================================================
int main(void) {
	char buffer[16];
	
	// Configuraci�n de pines para el sensor ultras�nico:
	// - Trig en PC0 (salida).
	// - Echo en PC1 (entrada con pull-up).
	DDRC |= (1 << PC0);     // PC0 como salida.
	DDRC &= ~(1 << PC1);    // PC1 como entrada.
	PORTC |= (1 << PC1);    // Activa resistor pull-up en PC1.
	
	// Inicializa el TWI en modo esclavo con direcci�n 0x20.
	TWI_Slave_Init(0x20);
	
	// Inicializa la UART para depuraci�n.
	uart_init();
	
	// Inicializa el PWM para el servo.
	servo_init();
	
	sei();  // Habilita las interrupciones globales.
	
	while (1) {
		// Actualiza la medici�n del sensor.
		measured_distance = (uint8_t)measure_distance();
		
		// Envia el valor medido por UART para verificaci�n.
		sprintf(buffer, "Dist: %d cm", measured_distance);
		uart_println(buffer);
		
		// Control del servo:
		// Si la distancia es 12 cm o menor, mueve el servo a 0� (pulso ? 1 ms).
		// En caso contrario, lo mantiene en 90� (pulso ? 1.5 ms).
		if (measured_distance <= 12) {
			OCR1B = 3500;  // 0� ~ 1 ms
			} else {
			OCR1B = 4000;  // 90� ~ 1.5 ms
		}
		
		_delay_ms(100);
	}
	
	return 0;
}
