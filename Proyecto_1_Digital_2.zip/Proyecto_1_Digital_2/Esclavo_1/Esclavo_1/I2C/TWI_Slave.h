#ifndef TWI_SLAVE_H_
#define TWI_SLAVE_H_

#include <avr/io.h>
#include <stdint.h>

// Inicializa el i2c en modo esclavo con la direcci�n dada (7 bits)
void TWI_Slave_Init(uint8_t slave_address);

#endif
