#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "I2C/TWI_Slave.h"
#include <stdio.h>

// Direcci�n I�C para este esclavo
#define SLAVE_LIGHT_ADDRESS 0x30

// Umbral para considerar que hay poca luz (valor ADC de 0 a 1023)
#define LIGHT_THRESHOLD 300

// Variable global para almacenar el valor de la fotoresistencia escalado a 8 bits (0-255)
volatile uint8_t measured_light = 0;
volatile uint8_t data_m = 0;

// ----------------------------------------------------------------------
// Funci�n para leer el ADC en un canal (usa AVcc como referencia)
// Se usar� el canal 0 (PC0) donde est� el divisor de voltaje con la fotoresistencia
// ----------------------------------------------------------------------
uint16_t read_ADC(uint8_t channel) {
	// Configura el multiplexor: AVcc como referencia y canal (0..7)
	ADMUX = (1 << REFS0) | (channel & 0x07);
	// Habilita el ADC y establece prescaler 128 (para 16 MHz)
	ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
	
	// Inicia la conversi�n
	ADCSRA |= (1 << ADSC);
	// Espera a que la conversi�n finalice
	while (ADCSRA & (1 << ADSC));
	
	return ADC; // Valor de 10 bits (0 a 1023)
}

// ----------------------------------------------------------------------
// Funci�n que actualiza los LED (en PD3 y PD4) seg�n el valor ADC
// Si el valor es menor que LIGHT_THRESHOLD (poca luz), enciende los LED;
// de lo contrario, los apaga.
// ----------------------------------------------------------------------
void update_LEDs(uint16_t adc_value) {
	if (adc_value < LIGHT_THRESHOLD) {
		// Enciende los LED: PD3 y PD4 en alto
		PORTD |= (1 << PD3) | (1 << PD4);
		} else {
		// Apaga los LED
		PORTD &= ~((1 << PD3) | (1 << PD4));
	}
}

// ----------------------------------------------------------------------
// ISR del TWI para responder a solicitudes del maestro.
// Cuando se solicita lectura (SLA+R), se env�a el valor de 'measured_light'.
// ----------------------------------------------------------------------
ISR(TWI_vect) {
	uint8_t status = TWSR & 0xF8;
	switch (status) {
		case 0x80: // SLA+W recibido: se limpia TWDR
		{ volatile uint8_t dummy = TWDR; }
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		data_m = TWDR;
		break;
		case 0xA8: // SLA+R recibido: el maestro solicita leer
		TWDR = measured_light;  // Env�a el valor medido
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
		default:
		TWCR = (1 << TWEN) | (1 << TWIE) | (1 << TWEA) | (1 << TWINT);
		break;
	}
}

// ----------------------------------------------------------------------
// Funciones UART para depuraci�n (opcional; 9600 bps)
// (Puedes desactivarlas si no las usas)
// ----------------------------------------------------------------------
void uart_init(void) {
	UBRR0H = 0;
	UBRR0L = 103;  // Para 16 MHz y 9600 bps.
	UCSR0B = (1 << TXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}
void uart_transmit(char data) {
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = data;
}
void uart_print(char *str) {
	while (*str) {
		uart_transmit(*str++);
	}
}
void uart_println(char *str) {
	uart_print(str);
	uart_transmit('\r');
	uart_transmit('\n');
}

// ----------------------------------------------------------------------
// Main del esclavo de fotoresistencia
// ----------------------------------------------------------------------
int main(void) {
	uint16_t adc_value;
	char buffer[16];
	
	DDRB |= (1<<2);
	
	// Configuraci�n de pines:
	// - Fotoresistencia: el divisor de voltaje est� en PC0 (entrada para ADC)
	DDRC &= ~(1 << PC0);  // PC0 como entrada
	// (Opcional) Desactivar la funci�n digital en PC0 para mayor precisi�n
	DIDR0 |= (1 << ADC0D);
	
	// LEDs en PD3 y PD4 como salidas
	DDRD |= (1 << PD3) | (1 << PD4);
	
	// Inicializa el TWI en modo esclavo con direcci�n SLAVE_LIGHT_ADDRESS (0x30)
	TWI_Slave_Init(SLAVE_LIGHT_ADDRESS);
	
	// (Opcional) Inicializa UART para depuraci�n
	uart_init();
	
	sei();  // Habilita interrupciones globales
	
	while (1) {
		// Lee el valor del ADC en el canal 0
		adc_value = read_ADC(0);
		
		// Actualiza el estado de los LED seg�n el valor le�do
		update_LEDs(adc_value);
		
		// Escala el valor ADC (10 bits: 0�1023) a 8 bits (0�255)
		measured_light = adc_value / 4;
		
		// (Opcional) Env�a por UART para depuraci�n
		sprintf(buffer, "Luz: %d", measured_light);
		uart_println(buffer);
		
		if (data_m == 1) {
            PORTB |= (1 << 2);
        } else if (data_m == 0) {
            PORTB &= ~(1 << 2);
        }
		
		_delay_ms(100);
	}
	
	return 0;
}
