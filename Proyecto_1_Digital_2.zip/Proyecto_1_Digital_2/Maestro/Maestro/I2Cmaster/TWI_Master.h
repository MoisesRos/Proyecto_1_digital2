#ifndef TWI_MASTER_H_
#define TWI_MASTER_H_

#include <avr/io.h>
#include <stdint.h>

// Inicializa el TWI en modo maestro con la frecuencia SCL 100000 para 100kHz
void TWI_Master_Init(uint32_t scl_clock);

// Env�a la condici�n START y la direcci�n (con bit R/W) al bus I2C
// Retorna 0 si todo OK, 1 en caso de error
uint8_t TWI_Start();

// Env�a un byte por el bus I2C. Retorna 0 si se recibe ACK, 1 en error
uint8_t TWI_Write(uint8_t data);

// Lee un byte y env�a ACK (si se van a leer m�s bytes)
uint8_t TWI_Read_ACK(void);

// Lee un byte y env�a NACK (usado para el �ltimo byte le�do)
uint8_t TWI_Read_NACK(void);

// Genera la condici�n STOP en el bus I2C
void TWI_Stop(void);

#endif
																													