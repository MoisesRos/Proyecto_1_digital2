#include "TWI_Master.h"
#define F_CPU 16000000UL  // Frecuencia de la CPU

void TWI_Master_Init(uint32_t scl_clock) {
	// Prescaler = 1
	TWSR = 0x00;
	// TWBR = ((F_CPU / scl_clock) - 16) / 2
	TWBR = ((F_CPU / scl_clock) - 16) / 2;
	TWCR = (1 << TWEN);
}

uint8_t TWI_Start() {
	// Enviar condici�n START
	TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT)));
}

uint8_t TWI_Write(uint8_t data) {
	TWDR = data;
	TWCR = (1 << TWINT) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT)));
}

uint8_t TWI_Read_ACK(void) {
	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
	while (!(TWCR & (1 << TWINT)));
	return TWDR;
}

uint8_t TWI_Read_NACK(void) {
	TWCR = (1 << TWINT) | (1 << TWEN);
	while (!(TWCR & (1 << TWINT)));
	return TWDR;
}

void TWI_Stop(void) {
	TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWSTO);
}
