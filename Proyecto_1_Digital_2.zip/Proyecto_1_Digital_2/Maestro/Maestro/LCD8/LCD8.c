#include "LCD8.h"

// Inicializa los pines y realiza la secuencia de arranque del LCD
void initLCD8(){
	// Datos en PORTD: PD2-PD7 como salidas
	DDRD |= (1 << PD2) | (1 << PD3) | (1 << PD4) | (1 << PD5) | (1 << PD6) | (1 << PD7);
	PORTD = 0;
	
	// Controles en PORTB: PB0, PB1 y PB5 como salidas
	DDRB |= (1 << PB0) | (1 << PB1) | (1 << PB5);
	PORTB &= ~((1 << PB0) | (1 << PB1) | (1 << PB5));
	
	// RS en PORTC: PC0 como salida
	DDRC |= (1 << PC0);
	PORTC &= ~(1 << PC0);
	
	// Secuencia de inicializaci�n
	LCDport(0x00);
	_delay_ms(50);
	LCDcomando(0x38);  // Funci�n: 8 bits, 2 l�neas, 5x8 puntos
	_delay_ms(10);
	LCDcomando(0x0C);  // Display encendido, cursor apagado
	_delay_ms(10);
	LCDcomando(0x06);  // Incremento, sin desplazamiento
	_delay_ms(10);
	LCDcomando(0x01);  // Limpia la pantalla
	_delay_ms(50);
}

void LCDcomando(char a) {
	PORTC &= ~(1 << PC0);  // RS = 0
	LCDport(a);
	PORTB |= (1 << PB5);   // Pulso en EN
	_delay_ms(5);
	PORTB &= ~(1 << PB5);
	_delay_ms(5);
}

void LCDport(char a) {
	if (a & 1)
	PORTD |= (1 << PD7);
	else
	PORTD &= ~(1 << PD7);
	
	if (a & 2)
	PORTD |= (1 << PD6);
	else
	PORTD &= ~(1 << PD6);
	
	if (a & 4)
	PORTD |= (1 << PD5);
	else
	PORTD &= ~(1 << PD5);
	
	if (a & 8)
	PORTD |= (1 << PD4);
	else
	PORTD &= ~(1 << PD4);
	
	if (a & 16)
	PORTB |= (1 << PB0);
	else
	PORTB &= ~(1 << PB0);
	
	if (a & 32)
	PORTB |= (1 << PB1);
	else
	PORTB &= ~(1 << PB1);
	
	if (a & 64)
	PORTD |= (1 << PD2);
	else
	PORTD &= ~(1 << PD2);
	
	if (a & 128)
	PORTD |= (1 << PD3);
	else
	PORTD &= ~(1 << PD3);
}

void LCDcaracter(char c) {
	PORTC |= (1 << PC0);  // RS = 1
	LCDport(c);
	_delay_ms(5);
	PORTB |= (1 << PB5);
	_delay_ms(5);
	PORTB &= ~(1 << PB5);
	_delay_ms(5);
}

void LCDcadena(char *a) {
	int i;
	for (i = 0; a[i] != '\0'; i++)
	LCDcaracter(a[i]);
}

void LCDderecha(void) {
	LCDcomando(0x1C);
}

void LCDizquierda(void) {
	LCDcomando(0x18);
}

void LCDcursor(char c, char f) {
	char temp;
	if (f == 1) {
		temp = 0x80 + c - 1;
		LCDcomando(temp);
		} else if (f == 2) {
		temp = 0xC0 + c - 1;
		LCDcomando(temp);
	}
}
