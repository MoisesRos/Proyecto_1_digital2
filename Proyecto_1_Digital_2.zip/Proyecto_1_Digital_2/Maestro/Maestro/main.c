#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "I2Cmaster/TWI_Master.h"
#include "LCD8/LCD8.h"
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

// =======================
// Definiciones del MPU6050
// =======================
#define MPU6050_ADDRESS      0x68
#define MPU6050_PWR_MGMT_1   0x6B
#define MPU6050_ACCEL_CONFIG 0x1C
#define MPU6050_ACCEL_XOUT_H 0x3B

// Direcciones I2C de los esclavos
#define DISTANCE_SENSOR_ADDRESS 0x20
#define LIGHT_SENSOR_ADDRESS    0x30

// =======================
// Variables y temporizaci�n
// =======================
volatile uint8_t read_flag = 0;
volatile uint8_t overflow_count = 0;  // Para Timer2 (aprox. 500 ms)

float accel_ms2 = 0;  // Aceleraci�n en m/s�
uint8_t distance = 0; // Distancia en cm
uint8_t light = 0;    // Valor de la fotoresistencia (0-255)
uint8_t acint = 0;
volatile uint8_t uart_received_data = 0; // Almacena el dato recibido por UART

// -----------------------
// ISR de Timer2 (Prescaler 1024)
// -----------------------
ISR(TIMER2_OVF_vect) {
	if (++overflow_count >= 31) { // ~500 ms
		read_flag = 1;
		overflow_count = 0;
	}
}

// =======================
// Funciones del MPU6050
// =======================

// Inicializa el MPU6050: despierta el sensor y configura el rango de aceleraci�n a �2g.
void MPU6050_Init() {
	// Despertar el sensor
	TWI_Start();
	TWI_Write((MPU6050_ADDRESS << 1) | 0);
	TWI_Write(MPU6050_PWR_MGMT_1);
	TWI_Write(0x00);
	TWI_Stop();
	
	// Configurar rango de aceleraci�n �2g
	TWI_Start();
	TWI_Write((MPU6050_ADDRESS << 1) | 0);
	TWI_Write(MPU6050_ACCEL_CONFIG);
	TWI_Write(0x00);
	TWI_Stop();
}

// Lee 16 bits desde el registro indicado del MPU6050.
int16_t MPU6050_Read16(uint8_t reg) {
	int16_t value;
	
	// Escribe el registro a leer
	TWI_Start();
	TWI_Write((MPU6050_ADDRESS << 1) | 0);
	TWI_Write(reg);
	
	// Lectura (repeated start)
	TWI_Start();
	TWI_Write((MPU6050_ADDRESS << 1) | 1);
	uint8_t high = TWI_Read_ACK();
	uint8_t low = TWI_Read_NACK();
	TWI_Stop();
	
	value = (high << 8) | low;
	return value;
}

// =======================
// Funciones UART Propias
// =======================

// Configuraci�n del m�dulo UART
void UART_Init(uint32_t baudrate) {
	uint16_t ubrr = (F_CPU / (16UL * baudrate)) - 1;
	UBRR0H = (ubrr >> 8); // Parte alta del baud rate
	UBRR0L = ubrr;        // Parte baja del baud rate
	UCSR0B = (1 << TXEN0) | (1 << RXEN0) | (1 << RXCIE0); // Habilitar TX, RX e interrupci�n RX
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // 8 bits de datos, 1 bit de parada
}

// Funci�n para enviar un car�cter por UART
void UART_SendChar(char c) {
	while (!(UCSR0A & (1 << UDRE0))); // Esperar a que el buffer est� vac�o
	UDR0 = c;                         // Enviar el car�cter
}

// Funci�n para enviar una cadena de texto por UART
void UART_SendString(const char *str) {
	while (*str) {
		UART_SendChar(*str++);
	}
}

// ISR para la recepci�n de datos por UART
ISR(USART_RX_vect) {
	uart_received_data = UDR0; // Leer el dato recibido
	//uart_received_data = atoi(uart_received_data);
}

// =======================
// Funci�n para enviar datos al segundo esclavo (sensor de luz)
// =======================
void SendToLightSensor(uint8_t data) {
	TWI_Start();
	TWI_Write((LIGHT_SENSOR_ADDRESS << 1) | 0); // Direcci�n del esclavo con bit de escritura
	TWI_Write(data);                            // Escribir el dato (1 o 0)
	TWI_Stop();
}


void sendCommandWithValue(char command, uint8_t value) {
	// Convierte el valor a una cadena de caracteres
	char buffer[4]; // Buffer para almacenar hasta 3 d�gitos m�s el terminador nulo
	itoa(value, buffer, 10); // Convierte el valor a una cadena en base 10 (decimal)

	// Env�a el comando
	while (!(UCSR0A & (1 << UDRE0))); // Espera a que el registro de datos est� vac�o
	UDR0 = command; // Env�a el comando

	// Env�a la cadena de caracteres
	for (uint8_t i = 0; buffer[i] != '\0'; i++) {
		while (!(UCSR0A & (1 << UDRE0))); // Espera a que el registro de datos est� vac�o
		UDR0 = buffer[i]; // Env�a el car�cter
	}

	// Env�a un car�cter de nueva l�nea
	while (!(UCSR0A & (1 << UDRE0))); // Espera a que el registro de datos est� vac�o
	UDR0 = '\n'; // Env�a el car�cter de nueva l�nea
}
// =======================
// Main
// =======================
int main(void) {
	char accel_str[12];
	char dist_str[16];
	char light_str[6];
	int16_t accel_raw;

	// Inicializa la LCD y limpia la pantalla.
	initLCD8();
	LCDcomando(0x01); // Limpia la LCD
	
	// Escribe el encabezado fijo en la fila 1:
	// "Ace:" en la columna 1, "Dist:" en la columna 9 y "Luz:" en la columna 17.
	LCDcursor(1,1);
	LCDcadena("Ace:  Dist: Luz:");

	// Inicializa el bus I�C a 100 kHz.
	TWI_Master_Init(100000);
	
	// Configura Timer2 para generar interrupciones (~500 ms) con prescaler 1024.
	TCCR2B = (1 << CS22) | (1 << CS20);  // Prescaler 1024
	TIMSK2 |= (1 << TOIE2);              // Habilita interrupci�n de Timer2
	
	sei(); // Habilita interrupciones globales
	
	// Inicializa el MPU6050.
	MPU6050_Init();
	
	// Inicializa UART a 9600 baudios
	UART_Init(9600);
	UART_SendString("UART inicializado\r\n");
	
	while (1) {
		// Si se ha cumplido el tiempo (aprox. 500 ms)
		if (read_flag) {
			read_flag = 0;
			
			// --- Lectura del MPU6050 ---
			accel_raw = MPU6050_Read16(MPU6050_ACCEL_XOUT_H);
			// Conversi�n: el factor 16384.0 es para �2g; se multiplica por 9.81 para pasar a m/s�.
			accel_ms2 = (accel_raw / 16384.0) * 9.81;
			
			// --- Lectura del sensor de distancia (desde el esclavo) ---
			TWI_Start();
			TWI_Write((DISTANCE_SENSOR_ADDRESS << 1) | 1);  // Direcci�n del esclavo con bit de lectura.
			distance = TWI_Read_NACK();                     // Lee el �nico byte.
			TWI_Stop();
			
			// --- Lectura de la fotoresistencia (desde el esclavo) ---
			TWI_Start();
			TWI_Write((LIGHT_SENSOR_ADDRESS << 1) | 1);  // Direcci�n del esclavo con bit de lectura.
			light = TWI_Read_NACK();                    // Lee el �nico byte.
			TWI_Stop();
			
			// --- Formateo de cadenas para la LCD ---
			dtostrf(accel_ms2, 6, 2, accel_str);         // Ejemplo: "  1.23"
			sprintf(dist_str, "%5d ", distance);       // Ejemplo: " 123 cm"
			sprintf(light_str, "%5d", light);            // Ejemplo: " 200"
			
			// --- Actualizaci�n de la LCD en la fila 2 ---
			LCDcursor(1,2);
			LCDcadena("                            ");  // Borra la fila 2
			
			LCDcursor(1,2);
			LCDcadena(accel_str);   // Imprime la aceleraci�n (columna 1)
			
			LCDcursor(6,2);
			LCDcadena(dist_str);    // Imprime la distancia (columna 10)
			
			LCDcursor(11,2);
			LCDcadena(light_str);   // Imprime la luz (columna 18)
			
			
			if (accel_ms2 < 0) {
				 acint = 0;
				} else if (accel_ms2 > 255) {
				acint = 255;
				} else {
				acint = (uint8_t)round(accel_ms2); // Redondea antes de convertir
			}
			
			// --- Env�o de datos por UART ---
			
			sendCommandWithValue('1', acint);
			sendCommandWithValue('2', distance);
			sendCommandWithValue('3', light);
			/*UART_SendString("1");
			UART_SendString(value);
			UART_SendString("\n");
			
			UART_SendString("2");
			UART_SendString(dist_str);
			UART_SendString("\n");
			
			UART_SendString("3");
			UART_SendString(light_str);
			UART_SendString("\n");*/
			
			// Retardo para evitar saturar el buffer de UART
			_delay_ms(100);
		}
		
		// --- Procesamiento del dato recibido por UART ---
		if (uart_received_data != 0) {
			// Enviar el dato recibido al segundo esclavo (sensor de luz)
			SendToLightSensor(uart_received_data);
			
			// Limpiar el dato recibido para evitar procesamientos repetidos
			uart_received_data = 0;
		}
	}
	
	return 0;
}