/*
 * UARTB.c
 *
 * Created: 27/02/2025 19:51:08
 *  Author: alane
 */ 
#include "UARTB.h"

void UARTsetup(void){
	// Configuraci�n UART
	UBRR0H = (BRC >> 8);  // Configurar baud rate alto
	UBRR0L = BRC;         // Configurar baud rate bajo
	UCSR0B = (1 << TXEN0) | (1 << RXEN0) | (1 << RXCIE0); // Habilitar transmisi�n, recepci�n e interrupci�n RX
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // Configurar formato: 8 bits de datos, 1 bit de parada
}

void enviarUART(char data) {
	while (!(UCSR0A & (1 << UDRE0)));  // Esperar a que el buffer est� vac�o
	UDR0 = data;  // Enviar dato
}

// Funci�n para enviar una cadena de caracteres por UART
void enviarStringUART(char* str) {
	while(*str) {
		enviarUART(*str++);
	}
	enviarUART('\n');
}

void sendCommandWithValue1(char command, uint8_t value) {
	// Convierte el valor a una cadena de caracteres
	char buffer[4]; // Buffer para almacenar hasta 3 d�gitos m�s el terminador nulo
	itoa(value, buffer, 10); // Convierte el valor a una cadena en base 10 (decimal)

	// Env�a el comando
	while (!(UCSR0A & (1 << UDRE0))); // Espera a que el registro de datos est� vac�o
	UDR0 = command; // Env�a el comando

	// Env�a la cadena de caracteres
	for (uint8_t i = 0; buffer[i] != '\0'; i++) {
		while (!(UCSR0A & (1 << UDRE0))); // Espera a que el registro de datos est� vac�o
		UDR0 = buffer[i]; // Env�a el car�cter
	}

	// Env�a un car�cter de nueva l�nea
	while (!(UCSR0A & (1 << UDRE0))); // Espera a que el registro de datos est� vac�o
	UDR0 = '\n'; // Env�a el car�cter de nueva l�nea
}
