/*
 * UARTB.h
 *
 * Created: 27/02/2025 19:51:20
 *  Author: alane
 */ 

#ifndef UARTB_H_
#define UARTB_H_
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// UART Baud rate
#define BAUD 9600
#define BRC ((F_CPU/16/BAUD) - 1)

//volatile char command = 0;
//volatile char buffer[4];  // Buffer para almacenar hasta 3 d�gitos m�s el terminador nulo

void UARTsetup(void);
void enviarUART(char data);
void enviarStringUART(char* str);
void sendCommandWithValue(char command, uint8_t value);


#endif /* UARTB_H_ */